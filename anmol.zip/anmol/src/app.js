const express = require("express");
const mongoose =require("mongoose");
const path =require("path");//used with static files
require("./db/conn");

const register =require("./models/register");
const contact =require("./models/contact");



const app = express();
const port = process.env.PORT || 3000;


mongoose.connect("mongodb://localhost:27017/GYM")
.then(()=>{
    
    console.log("data base connection done...")
}).catch(()=>{
    console.log("data base not connect..")
})


const staticpath = path.join(__dirname,"../public")
app.use(express.urlencoded({extended:false}));
app.set("view engine","hbs");

app.use(express.static(staticpath));



//routing .................................................................................
//app.get(path,callback)
app.get("/",(req,res)=>{
    res.render("login");
   
})
app.get("/register",(req,res)=>{
    res.render("register");
   
})
app.get("/about",(req,res)=>{
    res.render("about");

})
app.get("/contact",(req,res)=>{
    res.render("contact");

})
app.get("/quiz",(req,res)=>{
    res.render("quiz");

})
app.get("/chart",(req,res)=>{
    res.render("chart");

})

app.post("/register",async(req,res)=>{
    try{
      const reg=new register({
         username:req.body.username,
         email:req.body.email,
         password:req.body.password,
         cpassword:req.body.cpassword,
         
      })
 
      const ctct= await reg.save();
      res.status(201).render("login");
   
    }catch(error){
       res.status(500).send(error)
    }
 })
 app.post("/login",async(req,res)=>{
    try{
        const unam=req.body.username;
        const pass=req.body.password;
       const user=await register.findOne({username:unam});
    //    console.log(user);
       if(user.password==pass){
        res.status(201).render("index");
       }
      else{
        res.render("register")
      }
    }catch(error){
       res.status(500).render("register")
      //  res.status(500).send(error)
    }
 })

 app.post("/contact",async(req,res)=>{
    try{
      const reg=new contact({
         name:req.body.name,
         email:req.body.email,
         message:req.body.message,
         
      })
 
      const ctct= await reg.save();
      res.status(201).render("index");
   
    }catch(error){
       res.status(500).send(error)
    }
 })




//server create...
app.listen(port,() =>{
    console.log(`server is running at port ${port}`)
})

